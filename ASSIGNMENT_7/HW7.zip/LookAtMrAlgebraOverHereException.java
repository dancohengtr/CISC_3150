
public class LookAtMrAlgebraOverHereException extends Exception {

}
