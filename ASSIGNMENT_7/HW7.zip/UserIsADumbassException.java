
public class UserIsADumbassException extends Exception {

}
