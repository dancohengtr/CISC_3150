
public class IllegalOperationException extends Exception {

}
