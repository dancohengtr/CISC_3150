package parent;


public class parentClass {
	
	private static int someNumber = 7;
	

}
