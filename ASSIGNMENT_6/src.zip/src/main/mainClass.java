package main;

import parent.parentClass;


public class mainClass extends parentClass {
	
	
	

	public static void main(String[] args) {
		
		System.out.println(someNumber);
		

	}

}
